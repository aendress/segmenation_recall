rm (list=ls())
# check this
#http://www.ats.ucla.edu/stat/r/dae/melogit.htm
#http://www.sagepub.com/upm-data/38503_Chapter6.pdf
# Read in a random collection of custom functions
source ("/Users/endress/R.ansgar/tt.R")
source ("/Users/endress/R.ansgar/null.R")
#source ("helper_functions.R")

library ("gdata") # for reorder
library ("reshape2")
library(plyr)
library ("ggplot2")
library ("tidyr") # for gather and spread
library("plyr")   # for revalue
library (Hmisc) # for corr

library(FSA)

library ("lme4")
library (nlme)
library ("languageR")
library(lmerTest)
library (ez)
library(multcomp)


rm (cor2) # remove function for conflictig name

###

dat.e12 <- rbind(read.table ("recall.i.e1.cont.tab", header=T, sep="\t", comment.char = "%"),
                     read.table ("recall.i.e2.segm.tab", header=T, sep="\t", comment.char = "%"))

dat.e12$subj <- factor (tolower(as.character(dat.e12$subj)))

dat.e12.m <- aggregate(correct~condDir+language+subj, dat.e12, mean)

dat.e12.m.wide <- dcast (dat.e12.m,
                         language + subj ~ condDir,
                         value.var="correct") 

write.table (dat.e12,
             file="dat.e12.txt",
             quote=F, sep="\t", row.names=F, col.names=T)

write.table (dat.e12.m,
             file="dat.e12.m.txt",
             quote=F, sep="\t", row.names=F, col.names=T)

write.table (dat.e12.m.wide,
             file="dat.e12.wide.txt",
             quote=F, sep="\t", row.names=F, col.names=T)


tt4 (dat.e12.m.wide$recall.i.e1.cont)
with (dat.e12.m.wide,
      wilcox.test(recall.i.e1.cont, recall.i.e2.segm, paired=T))
